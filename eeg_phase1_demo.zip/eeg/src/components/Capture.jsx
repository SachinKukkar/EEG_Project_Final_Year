import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Capture({ progress, setProgress, setResult }) {
  const navigate = useNavigate();

  useEffect(() => {
    let interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 20) {
          clearInterval(interval);
          setResult("success"); // mock result
          setTimeout(() => navigate("/result"), 500);
          return 20;
        }
        return prev + 1;
      });
    }, 200);
    return () => clearInterval(interval);
  }, [setProgress, setResult, navigate]);

  return (
    <div className="bg-white shadow-lg rounded-2xl p-8 w-96 text-center">
      <h2 className="text-xl font-semibold mb-4 text-purple-600">
        Capturing EEG Signals...
      </h2>
      <div className="w-full bg-gray-200 rounded-full h-6 mb-4">
        <div
          className="bg-purple-600 h-6 rounded-full transition-all duration-200"
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      <p>{progress}% completed</p>
    </div>
  );
}

export default Capture;