import React from "react";
import { useNavigate } from "react-router-dom";

function Login({ setProgress }) {
  const navigate = useNavigate();

  const handleStart = () => {
    setProgress(0);
    navigate("/capture");
  };

  return (
    <div className="bg-white shadow-lg rounded-2xl p-8 w-96">
      <h1 className="text-2xl font-bold mb-6 text-center text-purple-600">
        EEG-Based Authentication
      </h1>
      <input
        type="text"
        placeholder="Enter Username"
        className="w-full p-3 border rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-purple-400"
      />
      <button
        onClick={handleStart}
        className="w-full bg-purple-600 text-white p-3 rounded-lg hover:bg-purple-700 transition"
      >
        Start Authentication
      </button>
    </div>
  );
}

export default Login;