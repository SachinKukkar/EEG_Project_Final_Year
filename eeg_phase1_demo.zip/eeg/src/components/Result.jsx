import React from "react";
import { useNavigate } from "react-router-dom";

function Result({ result }) {
  const navigate = useNavigate();
  return (
    <div className="bg-white shadow-lg rounded-2xl p-8 w-96 text-center">
      {result === "success" ? (
        <>
          <h2 className="text-2xl font-bold text-green-600 mb-4">
            Authentication Successful ✅
          </h2>
          <p>User verified using EEG signals.</p>
        </>
      ) : (
        <>
          <h2 className="text-2xl font-bold text-red-600 mb-4">
            Authentication Failed ❌
          </h2>
          <p>Please try again.</p>
        </>
      )}
      <button
        onClick={() => navigate("/")}
        className="mt-6 bg-purple-600 text-white p-3 rounded-lg hover:bg-purple-700 transition"
      >
        Back to Login
      </button>
    </div>
  );
}

export default Result;