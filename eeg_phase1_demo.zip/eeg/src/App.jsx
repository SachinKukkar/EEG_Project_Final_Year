import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Capture from "./components/Capture";
import Result from "./components/Result";

function App() {
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState(null);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-r from-blue-100 to-purple-100">
      <Routes>
        <Route path="/" element={<Login setProgress={setProgress} />} />
        <Route
          path="/capture"
          element={<Capture progress={progress} setProgress={setProgress} setResult={setResult} />}
        />
        <Route path="/result" element={<Result result={result} />} />
      </Routes>
    </div>
  );
}

export default App;